/****************************************************************************
** Meta object code from reading C++ file 'circularindicator.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../circularindicator.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'circularindicator.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CircularIndicator_t {
    QByteArrayData data[32];
    char stringdata0[427];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CircularIndicator_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CircularIndicator_t qt_meta_stringdata_CircularIndicator = {
    {
QT_MOC_LITERAL(0, 0, 17), // "CircularIndicator"
QT_MOC_LITERAL(1, 18, 17), // "startAngleChanged"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 15), // "endAngleChanged"
QT_MOC_LITERAL(4, 53, 19), // "minimumValueChanged"
QT_MOC_LITERAL(5, 73, 19), // "maximumValueChanged"
QT_MOC_LITERAL(6, 93, 12), // "valueChanged"
QT_MOC_LITERAL(7, 106, 16), // "lineWidthChanged"
QT_MOC_LITERAL(8, 123, 20), // "progressColorChanged"
QT_MOC_LITERAL(9, 144, 22), // "backgroundColorChanged"
QT_MOC_LITERAL(10, 167, 14), // "paddingChanged"
QT_MOC_LITERAL(11, 182, 13), // "setStartAngle"
QT_MOC_LITERAL(12, 196, 5), // "angle"
QT_MOC_LITERAL(13, 202, 11), // "setEndAngle"
QT_MOC_LITERAL(14, 214, 15), // "setMinimumValue"
QT_MOC_LITERAL(15, 230, 5), // "value"
QT_MOC_LITERAL(16, 236, 15), // "setMaximumValue"
QT_MOC_LITERAL(17, 252, 8), // "setValue"
QT_MOC_LITERAL(18, 261, 12), // "setLineWidth"
QT_MOC_LITERAL(19, 274, 5), // "width"
QT_MOC_LITERAL(20, 280, 16), // "setProgressColor"
QT_MOC_LITERAL(21, 297, 5), // "color"
QT_MOC_LITERAL(22, 303, 18), // "setBackgroundColor"
QT_MOC_LITERAL(23, 322, 10), // "setPadding"
QT_MOC_LITERAL(24, 333, 7), // "padding"
QT_MOC_LITERAL(25, 341, 10), // "startAngle"
QT_MOC_LITERAL(26, 352, 8), // "endAngle"
QT_MOC_LITERAL(27, 361, 12), // "minimumValue"
QT_MOC_LITERAL(28, 374, 12), // "maximumValue"
QT_MOC_LITERAL(29, 387, 9), // "lineWidth"
QT_MOC_LITERAL(30, 397, 13), // "progressColor"
QT_MOC_LITERAL(31, 411, 15) // "backgroundColor"

    },
    "CircularIndicator\0startAngleChanged\0"
    "\0endAngleChanged\0minimumValueChanged\0"
    "maximumValueChanged\0valueChanged\0"
    "lineWidthChanged\0progressColorChanged\0"
    "backgroundColorChanged\0paddingChanged\0"
    "setStartAngle\0angle\0setEndAngle\0"
    "setMinimumValue\0value\0setMaximumValue\0"
    "setValue\0setLineWidth\0width\0"
    "setProgressColor\0color\0setBackgroundColor\0"
    "setPadding\0padding\0startAngle\0endAngle\0"
    "minimumValue\0maximumValue\0lineWidth\0"
    "progressColor\0backgroundColor"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CircularIndicator[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       9,  158, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  104,    2, 0x06 /* Public */,
       3,    1,  107,    2, 0x06 /* Public */,
       4,    1,  110,    2, 0x06 /* Public */,
       5,    1,  113,    2, 0x06 /* Public */,
       6,    1,  116,    2, 0x06 /* Public */,
       7,    1,  119,    2, 0x06 /* Public */,
       8,    1,  122,    2, 0x06 /* Public */,
       9,    1,  125,    2, 0x06 /* Public */,
      10,    1,  128,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      11,    1,  131,    2, 0x0a /* Public */,
      13,    1,  134,    2, 0x0a /* Public */,
      14,    1,  137,    2, 0x0a /* Public */,
      16,    1,  140,    2, 0x0a /* Public */,
      17,    1,  143,    2, 0x0a /* Public */,
      18,    1,  146,    2, 0x0a /* Public */,
      20,    1,  149,    2, 0x0a /* Public */,
      22,    1,  152,    2, 0x0a /* Public */,
      23,    1,  155,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QColor,    2,
    QMetaType::Void, QMetaType::QColor,    2,
    QMetaType::Void, QMetaType::Int,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::QReal,   15,
    QMetaType::Void, QMetaType::QReal,   15,
    QMetaType::Void, QMetaType::QReal,   15,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::QColor,   21,
    QMetaType::Void, QMetaType::QColor,   21,
    QMetaType::Void, QMetaType::Int,   24,

 // properties: name, type, flags
      25, QMetaType::Int, 0x00495103,
      26, QMetaType::Int, 0x00495103,
      27, QMetaType::QReal, 0x00495103,
      28, QMetaType::QReal, 0x00495103,
      15, QMetaType::QReal, 0x00495103,
      29, QMetaType::Int, 0x00495103,
      30, QMetaType::QColor, 0x00495103,
      31, QMetaType::QColor, 0x00495103,
      24, QMetaType::Int, 0x00495103,

 // properties: notify_signal_id
       0,
       1,
       2,
       3,
       4,
       5,
       6,
       7,
       8,

       0        // eod
};

void CircularIndicator::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CircularIndicator *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->startAngleChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->endAngleChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->minimumValueChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 3: _t->maximumValueChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 4: _t->valueChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 5: _t->lineWidthChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->progressColorChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 7: _t->backgroundColorChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 8: _t->paddingChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->setStartAngle((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->setEndAngle((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->setMinimumValue((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 12: _t->setMaximumValue((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 13: _t->setValue((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 14: _t->setLineWidth((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->setProgressColor((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 16: _t->setBackgroundColor((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 17: _t->setPadding((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (CircularIndicator::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CircularIndicator::startAngleChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (CircularIndicator::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CircularIndicator::endAngleChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (CircularIndicator::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CircularIndicator::minimumValueChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (CircularIndicator::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CircularIndicator::maximumValueChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (CircularIndicator::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CircularIndicator::valueChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (CircularIndicator::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CircularIndicator::lineWidthChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (CircularIndicator::*)(QColor );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CircularIndicator::progressColorChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (CircularIndicator::*)(QColor );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CircularIndicator::backgroundColorChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (CircularIndicator::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CircularIndicator::paddingChanged)) {
                *result = 8;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<CircularIndicator *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->startAngle(); break;
        case 1: *reinterpret_cast< int*>(_v) = _t->endAngle(); break;
        case 2: *reinterpret_cast< qreal*>(_v) = _t->minimumValue(); break;
        case 3: *reinterpret_cast< qreal*>(_v) = _t->maximumValue(); break;
        case 4: *reinterpret_cast< qreal*>(_v) = _t->value(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->lineWidth(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->progressColor(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->backgroundColor(); break;
        case 8: *reinterpret_cast< int*>(_v) = _t->padding(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<CircularIndicator *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setStartAngle(*reinterpret_cast< int*>(_v)); break;
        case 1: _t->setEndAngle(*reinterpret_cast< int*>(_v)); break;
        case 2: _t->setMinimumValue(*reinterpret_cast< qreal*>(_v)); break;
        case 3: _t->setMaximumValue(*reinterpret_cast< qreal*>(_v)); break;
        case 4: _t->setValue(*reinterpret_cast< qreal*>(_v)); break;
        case 5: _t->setLineWidth(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setProgressColor(*reinterpret_cast< QColor*>(_v)); break;
        case 7: _t->setBackgroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 8: _t->setPadding(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject CircularIndicator::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickPaintedItem::staticMetaObject>(),
    qt_meta_stringdata_CircularIndicator.data,
    qt_meta_data_CircularIndicator,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CircularIndicator::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CircularIndicator::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CircularIndicator.stringdata0))
        return static_cast<void*>(this);
    return QQuickPaintedItem::qt_metacast(_clname);
}

int CircularIndicator::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickPaintedItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 9;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void CircularIndicator::startAngleChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void CircularIndicator::endAngleChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void CircularIndicator::minimumValueChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void CircularIndicator::maximumValueChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void CircularIndicator::valueChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void CircularIndicator::lineWidthChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void CircularIndicator::progressColorChanged(QColor _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void CircularIndicator::backgroundColorChanged(QColor _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void CircularIndicator::paddingChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
