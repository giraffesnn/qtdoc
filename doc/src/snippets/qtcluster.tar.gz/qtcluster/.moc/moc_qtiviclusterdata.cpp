/****************************************************************************
** Meta object code from reading C++ file 'qtiviclusterdata.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../qtiviclusterdata.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qtiviclusterdata.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ZonedProperties_t {
    QByteArrayData data[6];
    char stringdata0[59];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ZonedProperties_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ZonedProperties_t qt_meta_stringdata_ZonedProperties = {
    {
QT_MOC_LITERAL(0, 0, 15), // "ZonedProperties"
QT_MOC_LITERAL(1, 16, 11), // "zoneChanged"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 4), // "zone"
QT_MOC_LITERAL(4, 34, 15), // "doorOpenChanged"
QT_MOC_LITERAL(5, 50, 8) // "doorOpen"

    },
    "ZonedProperties\0zoneChanged\0\0zone\0"
    "doorOpenChanged\0doorOpen"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ZonedProperties[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       1,   28, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   24,    2, 0x06 /* Public */,
       4,    0,   27,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void,

 // properties: name, type, flags
       5, QMetaType::Bool, 0x00495001,

 // properties: notify_signal_id
       1,

       0        // eod
};

void ZonedProperties::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ZonedProperties *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->zoneChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->doorOpenChanged(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ZonedProperties::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ZonedProperties::zoneChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (ZonedProperties::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ZonedProperties::doorOpenChanged)) {
                *result = 1;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<ZonedProperties *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->doorOpen(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject ZonedProperties::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_ZonedProperties.data,
    qt_meta_data_ZonedProperties,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ZonedProperties::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ZonedProperties::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ZonedProperties.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int ZonedProperties::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 1;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void ZonedProperties::zoneChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ZonedProperties::doorOpenChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
struct qt_meta_stringdata_QtIVIClusterData_t {
    QByteArrayData data[70];
    char stringdata0[1019];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QtIVIClusterData_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QtIVIClusterData_t qt_meta_stringdata_QtIVIClusterData = {
    {
QT_MOC_LITERAL(0, 0, 16), // "QtIVIClusterData"
QT_MOC_LITERAL(1, 17, 19), // "vehicleSpeedChanged"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 12), // "vehicleSpeed"
QT_MOC_LITERAL(4, 51, 15), // "latitudeChanged"
QT_MOC_LITERAL(5, 67, 8), // "latitude"
QT_MOC_LITERAL(6, 76, 16), // "longitudeChanged"
QT_MOC_LITERAL(7, 93, 9), // "longitude"
QT_MOC_LITERAL(8, 103, 16), // "directionChanged"
QT_MOC_LITERAL(9, 120, 9), // "direction"
QT_MOC_LITERAL(10, 130, 15), // "flatTireChanged"
QT_MOC_LITERAL(11, 146, 8), // "flatTire"
QT_MOC_LITERAL(12, 155, 15), // "doorOpenChanged"
QT_MOC_LITERAL(13, 171, 8), // "doorOpen"
QT_MOC_LITERAL(14, 180, 19), // "lightFailureChanged"
QT_MOC_LITERAL(15, 200, 12), // "lightFailure"
QT_MOC_LITERAL(16, 213, 14), // "reverseChanged"
QT_MOC_LITERAL(17, 228, 7), // "Reverse"
QT_MOC_LITERAL(18, 236, 20), // "leftTurnLightChanged"
QT_MOC_LITERAL(19, 257, 13), // "leftTurnLight"
QT_MOC_LITERAL(20, 271, 21), // "rightTurnLightChanged"
QT_MOC_LITERAL(21, 293, 14), // "rightTurnLight"
QT_MOC_LITERAL(22, 308, 16), // "headLightChanged"
QT_MOC_LITERAL(23, 325, 9), // "headLight"
QT_MOC_LITERAL(24, 335, 16), // "parkLightChanged"
QT_MOC_LITERAL(25, 352, 9), // "parkLight"
QT_MOC_LITERAL(26, 362, 12), // "carIdChanged"
QT_MOC_LITERAL(27, 375, 5), // "carId"
QT_MOC_LITERAL(28, 381, 12), // "brakeChanged"
QT_MOC_LITERAL(29, 394, 7), // "brakeOn"
QT_MOC_LITERAL(30, 402, 17), // "engineTempChanged"
QT_MOC_LITERAL(31, 420, 10), // "engineTemp"
QT_MOC_LITERAL(32, 431, 14), // "oilTempChanged"
QT_MOC_LITERAL(33, 446, 7), // "oilTemp"
QT_MOC_LITERAL(34, 454, 18), // "oilPressureChanged"
QT_MOC_LITERAL(35, 473, 11), // "oilPressure"
QT_MOC_LITERAL(36, 485, 23), // "batteryPotentialChanged"
QT_MOC_LITERAL(37, 509, 16), // "batteryPotential"
QT_MOC_LITERAL(38, 526, 15), // "gasLevelChanged"
QT_MOC_LITERAL(39, 542, 8), // "gasLevel"
QT_MOC_LITERAL(40, 551, 10), // "rpmChanged"
QT_MOC_LITERAL(41, 562, 3), // "rpm"
QT_MOC_LITERAL(42, 566, 11), // "gearChanged"
QT_MOC_LITERAL(43, 578, 4), // "gear"
QT_MOC_LITERAL(44, 583, 12), // "zonesChanged"
QT_MOC_LITERAL(45, 596, 21), // "onVehicleSpeedChanged"
QT_MOC_LITERAL(46, 618, 4), // "zone"
QT_MOC_LITERAL(47, 623, 17), // "onLatitudeChanged"
QT_MOC_LITERAL(48, 641, 18), // "onLongitudeChanged"
QT_MOC_LITERAL(49, 660, 18), // "onDirectionChanged"
QT_MOC_LITERAL(50, 679, 17), // "onFlatTireChanged"
QT_MOC_LITERAL(51, 697, 17), // "onDoorOpenChanged"
QT_MOC_LITERAL(52, 715, 21), // "onLightFailureChanged"
QT_MOC_LITERAL(53, 737, 16), // "onReverseChanged"
QT_MOC_LITERAL(54, 754, 7), // "reverse"
QT_MOC_LITERAL(55, 762, 22), // "onLeftTurnLightChanged"
QT_MOC_LITERAL(56, 785, 23), // "onRightTurnLightChanged"
QT_MOC_LITERAL(57, 809, 18), // "onHeadLightChanged"
QT_MOC_LITERAL(58, 828, 18), // "onParkLightChanged"
QT_MOC_LITERAL(59, 847, 14), // "onCarIdChanged"
QT_MOC_LITERAL(60, 862, 14), // "onBrakeChanged"
QT_MOC_LITERAL(61, 877, 19), // "onEngineTempChanged"
QT_MOC_LITERAL(62, 897, 16), // "onOilTempChanged"
QT_MOC_LITERAL(63, 914, 20), // "onOilPressureChanged"
QT_MOC_LITERAL(64, 935, 25), // "onBatteryPotentialChanged"
QT_MOC_LITERAL(65, 961, 17), // "onGasLevelChanged"
QT_MOC_LITERAL(66, 979, 12), // "onRpmChanged"
QT_MOC_LITERAL(67, 992, 13), // "onGearChanged"
QT_MOC_LITERAL(68, 1006, 5), // "brake"
QT_MOC_LITERAL(69, 1012, 6) // "zoneAt"

    },
    "QtIVIClusterData\0vehicleSpeedChanged\0"
    "\0vehicleSpeed\0latitudeChanged\0latitude\0"
    "longitudeChanged\0longitude\0directionChanged\0"
    "direction\0flatTireChanged\0flatTire\0"
    "doorOpenChanged\0doorOpen\0lightFailureChanged\0"
    "lightFailure\0reverseChanged\0Reverse\0"
    "leftTurnLightChanged\0leftTurnLight\0"
    "rightTurnLightChanged\0rightTurnLight\0"
    "headLightChanged\0headLight\0parkLightChanged\0"
    "parkLight\0carIdChanged\0carId\0brakeChanged\0"
    "brakeOn\0engineTempChanged\0engineTemp\0"
    "oilTempChanged\0oilTemp\0oilPressureChanged\0"
    "oilPressure\0batteryPotentialChanged\0"
    "batteryPotential\0gasLevelChanged\0"
    "gasLevel\0rpmChanged\0rpm\0gearChanged\0"
    "gear\0zonesChanged\0onVehicleSpeedChanged\0"
    "zone\0onLatitudeChanged\0onLongitudeChanged\0"
    "onDirectionChanged\0onFlatTireChanged\0"
    "onDoorOpenChanged\0onLightFailureChanged\0"
    "onReverseChanged\0reverse\0"
    "onLeftTurnLightChanged\0onRightTurnLightChanged\0"
    "onHeadLightChanged\0onParkLightChanged\0"
    "onCarIdChanged\0onBrakeChanged\0"
    "onEngineTempChanged\0onOilTempChanged\0"
    "onOilPressureChanged\0onBatteryPotentialChanged\0"
    "onGasLevelChanged\0onRpmChanged\0"
    "onGearChanged\0brake\0zoneAt"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QtIVIClusterData[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      43,   14, // methods
      21,  398, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      22,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  229,    2, 0x06 /* Public */,
       4,    1,  232,    2, 0x06 /* Public */,
       6,    1,  235,    2, 0x06 /* Public */,
       8,    1,  238,    2, 0x06 /* Public */,
      10,    1,  241,    2, 0x06 /* Public */,
      12,    1,  244,    2, 0x06 /* Public */,
      14,    1,  247,    2, 0x06 /* Public */,
      16,    1,  250,    2, 0x06 /* Public */,
      18,    1,  253,    2, 0x06 /* Public */,
      20,    1,  256,    2, 0x06 /* Public */,
      22,    1,  259,    2, 0x06 /* Public */,
      24,    1,  262,    2, 0x06 /* Public */,
      26,    1,  265,    2, 0x06 /* Public */,
      28,    1,  268,    2, 0x06 /* Public */,
      30,    1,  271,    2, 0x06 /* Public */,
      32,    1,  274,    2, 0x06 /* Public */,
      34,    1,  277,    2, 0x06 /* Public */,
      36,    1,  280,    2, 0x06 /* Public */,
      38,    1,  283,    2, 0x06 /* Public */,
      40,    1,  286,    2, 0x06 /* Public */,
      42,    1,  289,    2, 0x06 /* Public */,
      44,    0,  292,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      45,    2,  293,    2, 0x08 /* Private */,
      47,    2,  298,    2, 0x08 /* Private */,
      48,    2,  303,    2, 0x08 /* Private */,
      49,    2,  308,    2, 0x08 /* Private */,
      50,    2,  313,    2, 0x08 /* Private */,
      51,    2,  318,    2, 0x08 /* Private */,
      52,    2,  323,    2, 0x08 /* Private */,
      53,    2,  328,    2, 0x08 /* Private */,
      55,    2,  333,    2, 0x08 /* Private */,
      56,    2,  338,    2, 0x08 /* Private */,
      57,    2,  343,    2, 0x08 /* Private */,
      58,    2,  348,    2, 0x08 /* Private */,
      59,    2,  353,    2, 0x08 /* Private */,
      60,    2,  358,    2, 0x08 /* Private */,
      61,    2,  363,    2, 0x08 /* Private */,
      62,    2,  368,    2, 0x08 /* Private */,
      63,    2,  373,    2, 0x08 /* Private */,
      64,    2,  378,    2, 0x08 /* Private */,
      65,    2,  383,    2, 0x08 /* Private */,
      66,    2,  388,    2, 0x08 /* Private */,
      67,    2,  393,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    5,
    QMetaType::Void, QMetaType::Double,    7,
    QMetaType::Void, QMetaType::Double,    9,
    QMetaType::Void, QMetaType::Bool,   11,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void, QMetaType::Bool,   23,
    QMetaType::Void, QMetaType::Bool,   25,
    QMetaType::Void, QMetaType::Int,   27,
    QMetaType::Void, QMetaType::Bool,   29,
    QMetaType::Void, QMetaType::Int,   31,
    QMetaType::Void, QMetaType::Double,   33,
    QMetaType::Void, QMetaType::Int,   35,
    QMetaType::Void, QMetaType::Double,   37,
    QMetaType::Void, QMetaType::Double,   39,
    QMetaType::Void, QMetaType::Int,   41,
    QMetaType::Void, QMetaType::Int,   43,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Double, QMetaType::QString,    3,   46,
    QMetaType::Void, QMetaType::Double, QMetaType::QString,    5,   46,
    QMetaType::Void, QMetaType::Double, QMetaType::QString,    7,   46,
    QMetaType::Void, QMetaType::Double, QMetaType::QString,    9,   46,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,   11,   46,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,   13,   46,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,   15,   46,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,   54,   46,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,   19,   46,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,   21,   46,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,   23,   46,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,   25,   46,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   27,   46,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,   29,   46,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   31,   46,
    QMetaType::Void, QMetaType::Double, QMetaType::QString,   33,   46,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   35,   46,
    QMetaType::Void, QMetaType::Double, QMetaType::QString,   37,   46,
    QMetaType::Void, QMetaType::Double, QMetaType::QString,   39,   46,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   41,   46,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   43,   46,

 // properties: name, type, flags
       3, QMetaType::Double, 0x00495001,
       5, QMetaType::Double, 0x00495001,
       7, QMetaType::Double, 0x00495001,
       9, QMetaType::Double, 0x00495001,
      11, QMetaType::Bool, 0x00495001,
      15, QMetaType::Bool, 0x00495001,
      54, QMetaType::Bool, 0x00495001,
      19, QMetaType::Bool, 0x00495001,
      21, QMetaType::Bool, 0x00495001,
      23, QMetaType::Bool, 0x00495001,
      25, QMetaType::Bool, 0x00495001,
      27, QMetaType::Int, 0x00495001,
      68, QMetaType::Bool, 0x00495001,
      31, QMetaType::Int, 0x00495001,
      33, QMetaType::Double, 0x00495001,
      35, QMetaType::Int, 0x00495001,
      37, QMetaType::Double, 0x00495001,
      39, QMetaType::Double, 0x00495001,
      41, QMetaType::Int, 0x00495001,
      43, QMetaType::Int, 0x00495001,
      69, QMetaType::QVariantMap, 0x00495001,

 // properties: notify_signal_id
       0,
       1,
       2,
       3,
       4,
       6,
       7,
       8,
       9,
      10,
      11,
      12,
      13,
      14,
      15,
      16,
      17,
      18,
      19,
      20,
      21,

       0        // eod
};

void QtIVIClusterData::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QtIVIClusterData *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->vehicleSpeedChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 1: _t->latitudeChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 2: _t->longitudeChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 3: _t->directionChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 4: _t->flatTireChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->doorOpenChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->lightFailureChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->reverseChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->leftTurnLightChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->rightTurnLightChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->headLightChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->parkLightChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->carIdChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->brakeChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->engineTempChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->oilTempChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 16: _t->oilPressureChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->batteryPotentialChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 18: _t->gasLevelChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 19: _t->rpmChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->gearChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->zonesChanged(); break;
        case 22: _t->onVehicleSpeedChanged((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 23: _t->onLatitudeChanged((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 24: _t->onLongitudeChanged((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 25: _t->onDirectionChanged((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 26: _t->onFlatTireChanged((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 27: _t->onDoorOpenChanged((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 28: _t->onLightFailureChanged((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 29: _t->onReverseChanged((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 30: _t->onLeftTurnLightChanged((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 31: _t->onRightTurnLightChanged((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 32: _t->onHeadLightChanged((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 33: _t->onParkLightChanged((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 34: _t->onCarIdChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 35: _t->onBrakeChanged((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 36: _t->onEngineTempChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 37: _t->onOilTempChanged((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 38: _t->onOilPressureChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 39: _t->onBatteryPotentialChanged((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 40: _t->onGasLevelChanged((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 41: _t->onRpmChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 42: _t->onGearChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QtIVIClusterData::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::vehicleSpeedChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::latitudeChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::longitudeChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::directionChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::flatTireChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::doorOpenChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::lightFailureChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::reverseChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::leftTurnLightChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::rightTurnLightChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::headLightChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::parkLightChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::carIdChanged)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::brakeChanged)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::engineTempChanged)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::oilTempChanged)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::oilPressureChanged)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::batteryPotentialChanged)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::gasLevelChanged)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::rpmChanged)) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::gearChanged)) {
                *result = 20;
                return;
            }
        }
        {
            using _t = void (QtIVIClusterData::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtIVIClusterData::zonesChanged)) {
                *result = 21;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<QtIVIClusterData *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< double*>(_v) = _t->vehicleSpeed(); break;
        case 1: *reinterpret_cast< double*>(_v) = _t->latitude(); break;
        case 2: *reinterpret_cast< double*>(_v) = _t->longitude(); break;
        case 3: *reinterpret_cast< double*>(_v) = _t->direction(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->flatTire(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->lightFailure(); break;
        case 6: *reinterpret_cast< bool*>(_v) = _t->reverse(); break;
        case 7: *reinterpret_cast< bool*>(_v) = _t->leftTurnLight(); break;
        case 8: *reinterpret_cast< bool*>(_v) = _t->rightTurnLight(); break;
        case 9: *reinterpret_cast< bool*>(_v) = _t->headLight(); break;
        case 10: *reinterpret_cast< bool*>(_v) = _t->parkLight(); break;
        case 11: *reinterpret_cast< int*>(_v) = _t->carId(); break;
        case 12: *reinterpret_cast< bool*>(_v) = _t->brake(); break;
        case 13: *reinterpret_cast< int*>(_v) = _t->engineTemp(); break;
        case 14: *reinterpret_cast< double*>(_v) = _t->oilTemp(); break;
        case 15: *reinterpret_cast< int*>(_v) = _t->oilPressure(); break;
        case 16: *reinterpret_cast< double*>(_v) = _t->batteryPotential(); break;
        case 17: *reinterpret_cast< double*>(_v) = _t->gasLevel(); break;
        case 18: *reinterpret_cast< int*>(_v) = _t->rpm(); break;
        case 19: *reinterpret_cast< int*>(_v) = _t->gear(); break;
        case 20: *reinterpret_cast< QVariantMap*>(_v) = _t->zoneFeatureMap(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject QtIVIClusterData::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_QtIVIClusterData.data,
    qt_meta_data_QtIVIClusterData,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *QtIVIClusterData::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QtIVIClusterData::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QtIVIClusterData.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "QQmlParserStatus"))
        return static_cast< QQmlParserStatus*>(this);
    if (!strcmp(_clname, "org.qt-project.Qt.QQmlParserStatus"))
        return static_cast< QQmlParserStatus*>(this);
    return QObject::qt_metacast(_clname);
}

int QtIVIClusterData::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 43)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 43;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 43)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 43;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 21;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 21;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 21;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 21;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 21;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QtIVIClusterData::vehicleSpeedChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QtIVIClusterData::latitudeChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QtIVIClusterData::longitudeChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QtIVIClusterData::directionChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QtIVIClusterData::flatTireChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void QtIVIClusterData::doorOpenChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void QtIVIClusterData::lightFailureChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void QtIVIClusterData::reverseChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void QtIVIClusterData::leftTurnLightChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void QtIVIClusterData::rightTurnLightChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void QtIVIClusterData::headLightChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void QtIVIClusterData::parkLightChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void QtIVIClusterData::carIdChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void QtIVIClusterData::brakeChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void QtIVIClusterData::engineTempChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void QtIVIClusterData::oilTempChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void QtIVIClusterData::oilPressureChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void QtIVIClusterData::batteryPotentialChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void QtIVIClusterData::gasLevelChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void QtIVIClusterData::rpmChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}

// SIGNAL 20
void QtIVIClusterData::gearChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 20, _a);
}

// SIGNAL 21
void QtIVIClusterData::zonesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 21, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
