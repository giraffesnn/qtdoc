/****************************************************************************
** Meta object code from reading C++ file 'gauge.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../gauge.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'gauge.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Gauge_t {
    QByteArrayData data[26];
    char stringdata0[307];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Gauge_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Gauge_t qt_meta_stringdata_Gauge = {
    {
QT_MOC_LITERAL(0, 0, 5), // "Gauge"
QT_MOC_LITERAL(1, 6, 12), // "valueChanged"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 5), // "value"
QT_MOC_LITERAL(4, 26, 12), // "angleChanged"
QT_MOC_LITERAL(5, 39, 5), // "angle"
QT_MOC_LITERAL(6, 45, 18), // "numVerticesChanged"
QT_MOC_LITERAL(7, 64, 11), // "numVertices"
QT_MOC_LITERAL(8, 76, 16), // "fillWidthChanged"
QT_MOC_LITERAL(9, 93, 9), // "fillWidth"
QT_MOC_LITERAL(10, 103, 13), // "radiusChanged"
QT_MOC_LITERAL(11, 117, 6), // "radius"
QT_MOC_LITERAL(12, 124, 15), // "minAngleChanged"
QT_MOC_LITERAL(13, 140, 8), // "minAngle"
QT_MOC_LITERAL(14, 149, 15), // "maxAngleChanged"
QT_MOC_LITERAL(15, 165, 8), // "maxAngle"
QT_MOC_LITERAL(16, 174, 15), // "minValueChanged"
QT_MOC_LITERAL(17, 190, 8), // "minValue"
QT_MOC_LITERAL(18, 199, 15), // "maxValueChanged"
QT_MOC_LITERAL(19, 215, 8), // "maxValue"
QT_MOC_LITERAL(20, 224, 16), // "doNotFillChanged"
QT_MOC_LITERAL(21, 241, 9), // "doNotFill"
QT_MOC_LITERAL(22, 251, 12), // "colorChanged"
QT_MOC_LITERAL(23, 264, 5), // "color"
QT_MOC_LITERAL(24, 270, 21), // "updateGeometryChanged"
QT_MOC_LITERAL(25, 292, 14) // "updateGeometry"

    },
    "Gauge\0valueChanged\0\0value\0angleChanged\0"
    "angle\0numVerticesChanged\0numVertices\0"
    "fillWidthChanged\0fillWidth\0radiusChanged\0"
    "radius\0minAngleChanged\0minAngle\0"
    "maxAngleChanged\0maxAngle\0minValueChanged\0"
    "minValue\0maxValueChanged\0maxValue\0"
    "doNotFillChanged\0doNotFill\0colorChanged\0"
    "color\0updateGeometryChanged\0updateGeometry"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Gauge[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
      12,  110, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      12,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   74,    2, 0x06 /* Public */,
       4,    1,   77,    2, 0x06 /* Public */,
       6,    1,   80,    2, 0x06 /* Public */,
       8,    1,   83,    2, 0x06 /* Public */,
      10,    1,   86,    2, 0x06 /* Public */,
      12,    1,   89,    2, 0x06 /* Public */,
      14,    1,   92,    2, 0x06 /* Public */,
      16,    1,   95,    2, 0x06 /* Public */,
      18,    1,   98,    2, 0x06 /* Public */,
      20,    1,  101,    2, 0x06 /* Public */,
      22,    1,  104,    2, 0x06 /* Public */,
      24,    1,  107,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QReal,    3,
    QMetaType::Void, QMetaType::QReal,    5,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Double,    9,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::Double,   13,
    QMetaType::Void, QMetaType::Double,   15,
    QMetaType::Void, QMetaType::Double,   17,
    QMetaType::Void, QMetaType::Double,   19,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void, QMetaType::QColor,   23,
    QMetaType::Void, QMetaType::Bool,   25,

 // properties: name, type, flags
       3, QMetaType::QReal, 0x00495103,
       5, QMetaType::QReal, 0x00495001,
       7, QMetaType::Int, 0x00495103,
      25, QMetaType::Bool, 0x00495103,
       9, QMetaType::Double, 0x00495103,
      11, QMetaType::Int, 0x00495103,
      13, QMetaType::Double, 0x00495103,
      15, QMetaType::Double, 0x00495103,
      17, QMetaType::Double, 0x00495103,
      19, QMetaType::Double, 0x00495103,
      21, QMetaType::Bool, 0x00495103,
      23, QMetaType::QColor, 0x00495103,

 // properties: notify_signal_id
       0,
       1,
       2,
      11,
       3,
       4,
       5,
       6,
       7,
       8,
       9,
      10,

       0        // eod
};

void Gauge::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Gauge *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->valueChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 1: _t->angleChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 2: _t->numVerticesChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->fillWidthChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 4: _t->radiusChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->minAngleChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 6: _t->maxAngleChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 7: _t->minValueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 8: _t->maxValueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 9: _t->doNotFillChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->colorChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 11: _t->updateGeometryChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Gauge::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::valueChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Gauge::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::angleChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Gauge::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::numVerticesChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Gauge::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::fillWidthChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Gauge::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::radiusChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Gauge::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::minAngleChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (Gauge::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::maxAngleChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (Gauge::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::minValueChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (Gauge::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::maxValueChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (Gauge::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::doNotFillChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (Gauge::*)(QColor );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::colorChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (Gauge::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Gauge::updateGeometryChanged)) {
                *result = 11;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<Gauge *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< qreal*>(_v) = _t->value(); break;
        case 1: *reinterpret_cast< qreal*>(_v) = _t->angle(); break;
        case 2: *reinterpret_cast< int*>(_v) = _t->numVertices(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->updateGeometry(); break;
        case 4: *reinterpret_cast< double*>(_v) = _t->fillWidth(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->radius(); break;
        case 6: *reinterpret_cast< double*>(_v) = _t->minAngle(); break;
        case 7: *reinterpret_cast< double*>(_v) = _t->maxAngle(); break;
        case 8: *reinterpret_cast< double*>(_v) = _t->minValue(); break;
        case 9: *reinterpret_cast< double*>(_v) = _t->maxValue(); break;
        case 10: *reinterpret_cast< bool*>(_v) = _t->doNotFill(); break;
        case 11: *reinterpret_cast< QColor*>(_v) = _t->color(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<Gauge *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setValue(*reinterpret_cast< qreal*>(_v)); break;
        case 2: _t->setNumVertices(*reinterpret_cast< int*>(_v)); break;
        case 3: _t->setUpdateGeometry(*reinterpret_cast< bool*>(_v)); break;
        case 4: _t->setFillWidth(*reinterpret_cast< double*>(_v)); break;
        case 5: _t->setRadius(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setMinAngle(*reinterpret_cast< double*>(_v)); break;
        case 7: _t->setMaxAngle(*reinterpret_cast< double*>(_v)); break;
        case 8: _t->setMinValue(*reinterpret_cast< double*>(_v)); break;
        case 9: _t->setMaxValue(*reinterpret_cast< double*>(_v)); break;
        case 10: _t->setDoNotFill(*reinterpret_cast< bool*>(_v)); break;
        case 11: _t->setColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject Gauge::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickItem::staticMetaObject>(),
    qt_meta_stringdata_Gauge.data,
    qt_meta_data_Gauge,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Gauge::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Gauge::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Gauge.stringdata0))
        return static_cast<void*>(this);
    return QQuickItem::qt_metacast(_clname);
}

int Gauge::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 12;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void Gauge::valueChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Gauge::angleChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Gauge::numVerticesChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Gauge::fillWidthChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Gauge::radiusChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Gauge::minAngleChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void Gauge::maxAngleChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void Gauge::minValueChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void Gauge::maxValueChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void Gauge::doNotFillChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void Gauge::colorChanged(QColor _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void Gauge::updateGeometryChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
